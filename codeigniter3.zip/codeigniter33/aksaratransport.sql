-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 13, 2024 at 07:47 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aksaratransport`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Kd_Admin` varchar(4) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Password` varchar(300) NOT NULL,
  `Nama` varchar(100) NOT NULL,
  `Alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Kd_Admin`, `Username`, `Password`, `Nama`, `Alamat`) VALUES
('AD02', 'Domz', '$2a$12$xCyLF3g3eS7kTO3XhsI/y.AgTUXQZX3G/UcW/.5oKImCpMrCWWWX6', 'Dominic', 'Berbah, Sleman'),
('AD03', 'Bli', '$2y$10$z2DOm8CJHgGEsDtIkK6wM.h/V/SjWZLElthRAXWHSIfvaAuuILS0e', 'bli', 'bali');

-- --------------------------------------------------------

--
-- Table structure for table `detail_transaksi`
--

CREATE TABLE `detail_transaksi` (
  `Kd_DTransaksi` varchar(10) NOT NULL,
  `Tgl_Transaksi` date NOT NULL,
  `Kd_Sewa` varchar(10) DEFAULT NULL,
  `Ket_Transaksi` text NOT NULL,
  `Total_Biaya` decimal(11,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mobil`
--

CREATE TABLE `mobil` (
  `Kd_Mobil` varchar(15) NOT NULL,
  `Nomor_Polisi` varchar(10) NOT NULL,
  `Merk` varchar(50) NOT NULL,
  `Nama` varchar(50) NOT NULL,
  `Harga_Sewa` decimal(11,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mobil`
--

INSERT INTO `mobil` (`Kd_Mobil`, `Nomor_Polisi`, `Merk`, `Nama`, `Harga_Sewa`) VALUES
('AB01', 'AB 2895 UZ', 'Toyota', 'Inova Reborn', 350000.00);

-- --------------------------------------------------------

--
-- Table structure for table `penyewa`
--

CREATE TABLE `penyewa` (
  `Kd_Penyewa` varchar(10) NOT NULL,
  `Foto_Penyewa` varchar(100) NOT NULL,
  `Nama` varchar(100) NOT NULL,
  `Alamat` text NOT NULL,
  `Nomor_Telepon` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sewa`
--

CREATE TABLE `sewa` (
  `Kd_Sewa` varchar(10) NOT NULL,
  `Kd_Mobil` varchar(15) DEFAULT NULL,
  `Kd_Supir` varchar(10) DEFAULT NULL,
  `Kd_Penyewa` varchar(10) DEFAULT NULL,
  `Tgl_Sewa` date NOT NULL,
  `Tgl_Pengembalian` date NOT NULL,
  `Total_Biaya` decimal(11,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `supir`
--

CREATE TABLE `supir` (
  `Kd_Supir` varchar(10) NOT NULL,
  `Nama` varchar(100) NOT NULL,
  `Alamat` text NOT NULL,
  `Nomor` varchar(12) NOT NULL,
  `Biaya` decimal(11,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supir`
--

INSERT INTO `supir` (`Kd_Supir`, `Nama`, `Alamat`, `Nomor`, `Biaya`) VALUES
('SP001', 'Ade', 'Kotagede, Yogyakarta', '085112549558', 150000.00);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `Kd_Transaksi` varchar(10) NOT NULL,
  `Kd_Admin` varchar(4) DEFAULT NULL,
  `KD_DTransaksi` varchar(10) DEFAULT NULL,
  `Metode_Pembayaran` varchar(20) NOT NULL,
  `Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Kd_Admin`);

--
-- Indexes for table `detail_transaksi`
--
ALTER TABLE `detail_transaksi`
  ADD PRIMARY KEY (`Kd_DTransaksi`),
  ADD UNIQUE KEY `Kd_Sewa` (`Kd_Sewa`);

--
-- Indexes for table `mobil`
--
ALTER TABLE `mobil`
  ADD PRIMARY KEY (`Kd_Mobil`);

--
-- Indexes for table `penyewa`
--
ALTER TABLE `penyewa`
  ADD PRIMARY KEY (`Kd_Penyewa`);

--
-- Indexes for table `sewa`
--
ALTER TABLE `sewa`
  ADD PRIMARY KEY (`Kd_Sewa`),
  ADD UNIQUE KEY `Kd_Kendaraan` (`Kd_Mobil`),
  ADD UNIQUE KEY `Kd_Supir` (`Kd_Supir`),
  ADD UNIQUE KEY `Kd_Penyewa` (`Kd_Penyewa`);

--
-- Indexes for table `supir`
--
ALTER TABLE `supir`
  ADD PRIMARY KEY (`Kd_Supir`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`Kd_Transaksi`),
  ADD UNIQUE KEY `Kd_Admin` (`Kd_Admin`),
  ADD UNIQUE KEY `KD_DTransaksi` (`KD_DTransaksi`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `detail_transaksi`
--
ALTER TABLE `detail_transaksi`
  ADD CONSTRAINT `detail_transaksi_ibfk_1` FOREIGN KEY (`Kd_Sewa`) REFERENCES `sewa` (`Kd_Sewa`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sewa`
--
ALTER TABLE `sewa`
  ADD CONSTRAINT `sewa_ibfk_1` FOREIGN KEY (`Kd_Supir`) REFERENCES `supir` (`Kd_Supir`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `sewa_ibfk_2` FOREIGN KEY (`Kd_Penyewa`) REFERENCES `penyewa` (`Kd_Penyewa`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `sewa_ibfk_3` FOREIGN KEY (`Kd_Mobil`) REFERENCES `mobil` (`Kd_Mobil`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`Kd_Admin`) REFERENCES `admin` (`Kd_Admin`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`KD_DTransaksi`) REFERENCES `detail_transaksi` (`Kd_DTransaksi`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
