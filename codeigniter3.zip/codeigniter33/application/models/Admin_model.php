<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin_model extends CI_Model
{

    public function get_admin($username)
    {
        $this->db->where('Username', $username);
        return $this->db->get('admin')->row_array();
    }

    public function get_kendaraan($kd_kendaraan)
    {
        $this->db->where('Kode Kendaraan', $kd_kendaraan);
        return $this->db->get('kendaraan')->row_array();
    }

    public function insert_data($data)
    {
        $this->db->insert('Admin', $data);
    }

    public function insert_mobil($data){
        $this->db->insert('Mobil', $data);
    }

    public function insert_supir($data){
        $this->db->insert('Supir', $data);
    }

    public function insert_penyewa($data){
        $this->db->insert('Penyewa', $data);
    }
    public function insert_sewa($data){
        $this->db->insert('Sewa', $data);
    }
    
    public function insert_transaksi ($data){
        $this->db->insert('Transaksi', $data);
    }

    public function update($where, $data)
    {
        $this->db->where($where);
        $this->db->update('Admin', $data);
    }

        public function updateSupir($where, $data)
    {
        $this->db->where($where);
        $this->db->update('Supir', $data);
    }

    public function updateSewa($where, $data){
        $this->db->where($where);
        $this->db->update('Sewa', $data);
    }

    public function delete($id)
    {
        $this->db->where('Kd_Admin', $id);
        $this->db->delete('Admin');
    }

    public function deleteMobil($id)
    {
    $this->db->where('Kd_Mobil', $id);
    $this->db->delete('Mobil');
    }

    public function deleteSupir($id)
    {
        $this->db->where('Kd_Supir', $id);
        $this->db->delete('Supir');
    }

    public function deletePenyewa($id) {
        $this->db->where('Kd_Penyewa', $id);
        $this->db->delete('Penyewa');
    }



}