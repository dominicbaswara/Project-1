<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_Register extends CI_Model
{
    public function register($username, $password, $nama, $alamat)
    {
        // Data yang akan diinsert
        $data = array(
            'username' => $username,
            'password' => $password,
            'nama' => $nama,
            'alamat' => $alamat
        );

        // Insert data ke tabel admin
        $this->db->insert('admin', $data);

        // Ambil id (kode admin) yang baru saja di-generate
        $kode_admin = $this->db->insert_id();

        return $kode_admin; // Mengembalikan kode admin yang baru saja di-generate
    }

    public function updateAdmin($where, $data)
    {
        $this->db->where($where);
        $this->db->update('admin', $data);
    }

    public function get_user($user)
    {
        $this->db->where('username', $user);
        $query = $this->db->get('user');
        return $query->row_array();
    }
}
?>
