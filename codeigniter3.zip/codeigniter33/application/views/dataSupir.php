<body>
    <div class="home" id="formDashboard">
        <div class="home-content">
            <div class="supir-button">
                <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                    data-bs-target="#tambahSupirModal" style="margin-left: 5rem;">Input Data Supir</button>
            </div>
            <div class="card tabel">
                <div align="left" style="margin: 1rem calc(100rem/30);">
                    <h2 style="margin-top: 1rem; margin-bottom:1rem; margin-left:1rem;"><?= $title ?></h2>
                    <table id="example" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr>
                                <th>Kode Supir</th>
                                <th>Nama</th>
                                <th>Alamat</th>
                                <th>Nomor Telephone</th>
                                <th>Biaya</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
							foreach ($Supir as $row)
								echo "
										<tr>
											<td>" . $row['Kd_Supir'] . "</td>
											<td>" . $row['Nama'] . "</td>
											<td>" . $row['Alamat'] . "</td>
											<td>" . $row['Nomor'] . "</td>
											<td>" . $row['Biaya'] . "</td>
                                            <td>
    												<div class='btn-group' role='group' aria-label='Basic outlined example'>
    													<button type='button' class='btn btn-outline-primary' data-bs-toggle='modal' data-bs-target='#editSupirModal" . $row['Kd_Supir'] . "'>Edit</button>
    													<a class='btn btn-outline-primary' href='" . base_url('dashboard/delete?Kd_Admin=' . $row['Kd_Supir']) . "'>Delete</a> 

    													<div class='modal fade' id='editSupirModal" . $row['Kd_Supir'] . "' tabindex='-1' aria-labelledby='exampleModalLabel' aria-hidden='true'>
    														<div class='modal-dialog'>
    															<div class='modal-content'>
    																<div class='modal-header'>
    																	<h1 class='modal-title fs-5' id='exampleModalLabel'>Edit Data Supir</h1>
    																	<button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
    																</div>
                                    								<div class='modal-body'>" ?>
                                                                        <form action='<?= base_url('dashboard/editSupir')  ?>' method='POST' enctype='multipart/form-data'>
                                                                        <?= "
                                                                        <div class='mb-3'>
                                                                            <label for='recipient-name' class='col-form-label'>Kode Admin :</label>
                                                                            <input type='text' class='form-control' name='kdSupir' readonly value='" . $row['Kd_Supir'] . "'>
                                                                        </div>
                                                                        <div class='mb-3'>
                                                                            <label for='message-text' class='col-form-label'>Nama :</label>
                                                                             <input type='text' class='form-control' name='nama'>
                                                                        </div>
                                                                        <div class='mb-3'>
                                                                            <label for='message-text' class='col-form-label'>Alamat :</label>
                                                                            <input type=text' class='form-control' name='alamat'>
                                                                        </div>
                                                                        <div class='mb-3'>
                                                                            <label for='message-text' class='col-form-label'>Nomor :</label>
                                                                            <input type='text' class='form-control' name='nomor'>
                                                                        </div>
                                                                        <div class='mb-3'>
                                                                            <label for='message-text' class='col-form-label'>Biaya :</label>
                                                                            <input type='text' class='form-control' name='biaya'>
                                                                        </div>
                                                                    </div>
                                                                    <div class='modal-footer'>
                                                                        <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Close</button>
                                                                        <button type='submit' class='btn btn-primary'>Edit Data</button>
                                                                    </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
										</tr>
									";
							?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->

    <div class="modal fade" id="tambahSupirModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Data Supir</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?= base_url('dashboard/tambahSupir')  ?>" method="POST"
                        enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">Kode Supir :</label>
                            <input type="text" class="form-control" name="kdSupir">
                        </div>
                        <div class="mb-3">
                            <label for="message-text" class="col-form-label">Nama :</label>
                            <input type="text" class="form-control" name="nama">
                        </div>
                        <div class="mb-3">
                            <label for="message-text" class="col-form-label">Alamat :</label>
                            <input type="text" class="form-control" name="alamat">
                        </div>
                        <div class="mb-3">
                            <label for="message-text" class="col-form-label">Nomor Telephone :</label>
                            <input type="text" class="form-control" name="nomor">
                        </div>
                        <div class="mb-3">
                            <label for="message-text" class="col-form-label">Biaya :</label>
                            <input type="text" class="form-control" name="biaya">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Tambah Data</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
<script>
$(document).ready(function() {
    $('#example').DataTable();
});
</script>
<script src="<?php echo base_url('asset\js\script.js') ?>"></script>

</html>