<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css' rel='stylesheet'>
    <link rel='stylesheet' href='https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css'>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel='stylesheet' href='https://unpkg.com/boxicons@latest/css/boxicons.min.css'>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css'>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?= base_url('asset/css/style.css') ?>">
    <title><?= $title ?></title>
</head>

<body>
    <?php

    $flashdata = $this->session->flashdata('notifikasi');
        $flashdata_error = $this->session->flashdata('error');
        
        if($flashdata){
            ?>
                <script>
                    Swal.fire({
                        title: "<?= $flashdata ?>",
                        icon: "success"
                    });
                </script>
            <?php
        }
        if($flashdata_error){
            ?>
                <script>
                    Swal.fire({
                        title: "<?= $flashdata_error ?>",
                        icon: "error"
                    });
                </script>
            <?php
        }
    ?>
    <!-- Sidebar -->
    <nav class='sidebar'>
        <header>
            <div class='image-text'>
                <!-- <span class='image'>
                <img class='big' src="<?= base_url('asset/image/header.png') ?>" alt=''>
                <img class='mini' src="<?= base_url('asset/image/logo.png') ?>" alt=''>
            </span> -->
                <h3>Aksara Transport</h3>
            </div>
        </header>
        <div class='menu-bar'>
            <div class='menu'>
                <ul class='menu-links'>
                    <li class='nav-link aktif'>
                        <a href="<?= base_url('dashboard') ?>">
                            <i class='bx bx-home-alt icon'></i>
                            <span class='text nav-text'>Dashboard</span>
                        </a>
                    </li>
                    <li class='nav-link'>
                        <a href="<?= base_url('dashboard/dtMobil') ?>">
                            <i class='bx bx-user icon'></i>
                            <span class='text nav-text'>Data Mobil</span>
                        </a>
                    </li>
                    <li class='nav-link'>
                        <a href="<?= base_url('dashboard/dtAdmin') ?>">
                            <i class='bx bx-clinic icon'></i>
                            <span class='text nav-text'>Data Admin</span>
                        </a>
                    </li>
                    <li class='nav-link'>
                        <a href="<?= base_url('dashboard/dtSupir') ?>">
                            <i class='bx bx-file-find icon'></i>
                            <span class='text nav-text'>Data Supir</span>
                        </a>
                    </li>
                    <li class='nav-link'>
                        <a href="<?= base_url('dashboard/dtPenyewa') ?>">
                            <i class='bx bx-file-find icon'></i>
                            <span class='text nav-text'>Data Penyewa</span>
                        </a>
                    </li>
                    <li class='nav-link'>
                        <a href="<?= base_url('dashboard/dtSewa') ?>">
                            <i class='bx bx-file-find icon'></i>
                            <span class='text nav-text'>Data Sewa</span>
                        </a>
                    </li>
                    <li class='nav-link'>
                        <a href="<?= base_url('dashboard/dtTransaksi') ?>">
                            <i class='bx bx-file-find icon'></i>
                            <span class='text nav-text'>Data Transaksi</span>
                        </a>
                    </li>
                </ul>
            </div>
            <div class='bottom-content'>
                <li class=''>
                    <a href="<?= site_url('login/logout') ?>">
                        <i class='bx bx-log-out icon'></i>
                        <span class='text nav-text'>Logout</span>
                    </a>
                </li>
            </div>
        </div>
    </nav>
    <!-- Akhir Sidebar -->

    <!-- Optional: section for home content -->
    <!-- 
<section class='home'>
    <nav>
        <div class='image-text'>
            <i class='bx bx-chevron-left toggle'></i>
            <span class='name'><?= $title . " " . $admin['Name'] ?></span>
        </div>
    </nav>
</section>
-->

</body>

</html>