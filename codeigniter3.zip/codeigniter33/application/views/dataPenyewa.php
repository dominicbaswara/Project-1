<body>
	<div class="home" id="formDashboard">
		<div class="home-content">
		<div class="mobil-button">
			<button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#tambahPenyewaModal" style="margin-left: 5rem;">Input Data Penyewa</button>
		</div>
			<div class="card tabel">
				<div align="left" style="margin: 1rem calc(100rem/30);">
					<h2 style="margin-top: 1rem; margin-bottom:1rem; margin-left:1rem;">Data Penyewa</h2>
					<table id="example" class="table table-striped table-bordered" style="width:100%">
							<thead>
								<tr>
									<th>Kode Penyewa</th>
									<th>Foto Penyewa</th>
									<th>Nama</th>
									<th>Alamat</th>
									<th>Nomor Telephone</th>
									<th>Aksi</th>

								</tr>
							</thead>
							<tbody>
								<?php
								foreach ($Penyewa as $row)
									echo "
										<tr>
											<td>" . $row['Kd_Penyewa'] . "</td>
											<td><img src='" . base_url('asset/image-upload/' . $row['Foto_Penyewa']) . "' alt='Foto Penyewa' width='100' height='100'></td>
											<td>" . $row['Nama'] . "</td>
											<td>" . $row['Alamat'] . "</td>
											<td>" . $row['Nomor_Telepon'] . "</td>
											<td>
    												<div class='btn-group' role='group' aria-label='Basic outlined example'>
    													<a class='btn btn-outline-primary' href='" . base_url('dashboard/deletePenyewa?Kd_Penyewa=' . $row['Kd_Penyewa']) . "'>Delete</a> 
    												</div>
    										</td>
										</tr>
									";
								?>
							</tbody>
						</table>
				</div>
			</div>
		</div>
	</div>
	<!-- Modal -->
	<div class="modal fade" id="tambahPenyewaModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Data Penyewa</h1>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
						</div>
					<div class="modal-body">
						<form action="<?= base_url('dashboard/tambahPenyewa')  ?>" method="POST"
						enctype="multipart/form-data">
							<div class="mb-3">
								<label for="recipient-name" class="col-form-label">Kode Penyewa :</label>
								<input type="text" class="form-control" name="kdPenyewa">
							</div>
							<div class="input-group mb-3">
							  <input type="file" class="form-control" id="inputFile" name="foto">
							  <label class="input-group-text" for="inputGroupFile02" placeholder="upload file">Upload</label>
							</div>
							<div class="mb-3">
								<label for="message-text" class="col-form-label">Nama :</label>
								<input type="text" class="form-control" name="nama">
							</div>
							<div class="mb-3">
								<label for="message-text" class="col-form-label">Alamat :</label>
								<input type="text" class="form-control" name="alamat">
							</div>
							<div class="mb-3">
								<label for="message-text" class="col-form-label">Nomor Telephone :</label>
								<input type="text" class="form-control" name="nomor">
							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
								<button type="submit" class="btn btn-primary">Tambah Data</button>
							</div>
						</form>
					</div>
				</div>
		</div>
	</div>

</body>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    });
</script>
<script src="<?php echo base_url('asset\js\script.js') ?>"></script>
</html>