<body>
	<div class="home" id="formDashboard">
		<div class="home-content">
		<div class="sewa-button">
			<button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#tambahSewaModal" style="margin-left: 5rem;">Input Data Sewa</button>
		</div>
			<div class="card tabel">
				<div align="left" style="margin: 1rem calc(100rem/30);">
					<h2 style="margin-top: 1rem; margin-bottom:1rem; margin-left:1rem;"><?= $title?></h2>
					<table id="example" class="table table-striped table-bordered" style="width:100%">
							<thead>
								<tr>
									<th>Kode Sewa</th>
									<th>Kode Mobil</th>
									<th>Kode Supir</th>
									<th>Kode Penyewa</th>
									<th>Tanggal Sewa</th>
									<th>Tanggal Pengembalian</th>
									<th>Total Biaya</th>
                                    <th>Aksi</th>
								</tr>
							</thead>
							<tbody>
								<?php
								foreach ($Sewa as $row)
									echo "
										<tr>
											<td>" . $row['Kd_Sewa'] . "</td>
											<td>" . $row['Kd_Mobil'] . "</td>
											<td>" . $row['Kd_Supir'] . "</td>
											<td>" . $row['Kd_Penyewa'] . "</td>
											<td>" . $row['Tgl_Sewa'] . "</td>
											<td>" . $row['Tgl_Pengembalian'] . "</td>
											<td>" . $row['Total_Biaya'] . "</td>
                                            <td> 
                                               <div class='btn-group' role='group' aria-label='Basic outlined example'>
                                                        <button type='button' class='btn btn-outline-primary' data-bs-toggle='modal' data-bs-target='#editSewaModal" . $row['Kd_Sewa'] . "'>Edit</button>
                                                        <a class='btn btn-outline-primary' href='" . base_url('dashboard/deleteSewa?Kd_Sewa=' . $row['Kd_Sewa']) . "'>Delete</a> 
                                            </div>
                                            </td>


                                            <div class='modal fade' id='editSewarModal" . $row['Kd_Sewa'] . "' tabindex='-1' aria-labelledby='exampleModalLabel' aria-hidden='true'>
                                                            <div class='modal-dialog'>
                                                                <div class='modal-content'>
                                                                    <div class='modal-header'>
                                                                        <h1 class='modal-title fs-5' id='exampleModalLabel'>Edit Data Supir</h1>
                                                                        <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                                                                    </div>
                                                                    <div class='modal-body'>" ?>
                                                                    <form action='<?= base_url('dashboard/editSupir')  ?>' method='POST' enctype='multipart/form-data'>
                                                                        <?= "
                                                                            <div class='mb-3'>
                                                                                <label for='recipient-name' class='col-form-label'>Kode Admin :</label>
                                                                                <input type='text' class='form-control' name='kdSupir' readonly value='" . $row['Kd_Supir'] . "'>
                                                                            </div>
                                                                            <div class='mb-3'>
                                                                                <label for='message-text' class='col-form-label'>Nama :</label>
                                                                                <input type='text' class='form-control' name='nama'  value='" . $row['Nama'] . "'>
                                                                            </div>
                                                                            <div class='mb-3'>
                                                                                <label for='message-text' class='col-form-label'>Alamat :</label>
                                                                                <input type='text' class='form-control' name='alamat' value='".$row['Alamat']."'>
                                                                            </div>
                                                                            <div class='mb-3'>
                                                                                <label for='message-text' class='col-form-label'>Nomor :</label>
                                                                                <input type='text' class='form-control' name='nomor'  value='" . $row['Nomor'] . "'>
                                                                            </div>
                                                                            <div class='mb-3'>
                                                                                <label for='message-text' class='col-form-label'>Biaya :</label>
                                                                                <input type='text' class='form-control' name='biaya'  value='" . $row['Biaya'] . "'>
                                                                            </div>
                                                                        <div class='modal-footer'>
                                                                            <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Close</button>
                                                                            <button type='submit' class='btn btn-primary'>Edit Data</button>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                             </div>
										</tr>
									";
								?>
							</tbody>
						</table>
				</div>
			</div>
		</div>
	</div>
	<div class="modal fade" id="tambahSewaModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Data Sewa</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?= base_url('dashboard/tambahSewa') ?>" method="POST">
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">Kode Sewa :</label>
                            <input type="text" class="form-control" name="kdSewa">
                        </div>
                        <div class="mb-3">
                            <label for="message-text" class="col-form-label">Kode Mobil :</label>
                            <select class="form-control" name="kdMobil">
                                <?php foreach ($Mobil as $row): ?>
                                    <option value="<?php echo $row['Kd_Mobil']; ?>"><?php echo $row['Kd_Mobil']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="message-text" class="col-form-label">Kode Supir :</label>
                            <select class="form-control" name="kdSupir">
                                <?php foreach ($Supir as $row): ?>
                                    <option value="<?php echo $row['Kd_Supir']; ?>"><?php echo $row['Kd_Supir']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>	
                        <div class="mb-3">
                            <label for="message-text" class="col-form-label">Kode Penyewa :</label>
                            <select class="form-control" name="kdPenyewa">
                                <?php foreach ($Penyewa as $row): ?>
                                    <option value="<?php echo $row['Kd_Penyewa']; ?>"><?php echo $row['Kd_Penyewa']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="message-text" class="col-form-label">Tanggal Sewa :</label>
                            <input type="date" class="form-control" name="tanggalSewa">
                        </div>
                        <div class="mb-3">
                            <label for="message-text" class="col-form-label">Tanggal Pengembalian :</label>
                            <input type="date" class="form-control" name="tanggalPengembalian">
                        </div>
                        <div class="mb-3">
                            <label for="message-text" class="col-form-label">Total Biaya :</label>
                            <input type="text" class="form-control" name="biaya">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Tambah Data</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    });
</script>
<script src="<?php echo base_url('asset\js\script.js') ?>"></script>
</html>