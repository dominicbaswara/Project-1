<body>
<body>
	<div class="home" id="formDashboard">
		<div class="home-content">
			<div class="card tabel">
				<div align="left" style="margin: 1rem calc(100rem/30);">
					<h2 style="margin-top: 1rem; margin-bottom:1rem; margin-left:1rem;">Data Admin</h2>
					<table id="example" class="table table-striped table-bordered" style="width:100%">
							<thead>
								<tr>
									<th> </th>
									<th>USERNAME</th>
									<th>NAMA</th>
									<th>ALAMAT</th>
								</tr>
							</thead>
							<tbody>
								 <?php
								foreach ($Admin as $row)
									echo "
										<tr>
											<td>" . $row['Username'] . "</td>
											<td>" . $row['Nama'] . "</td>
											<td>" . $row['Alamat'] . "</td>
										</tr>
									";
								?> 
							</tbody>
						</table>
				</div>
			</div>
		</div>
	</div>
</body>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    });
</script>
<script src="<?php echo base_url('asset\js\script.js') ?>"></script>
</html>
<button type="button" class="btn btn-secondary" <?= site_url('login/logout') ?>>Logout</button>
<!-- <p><a href="<?= site_url('login/logout') ?>">Logout</a></p> -->
</body>





<script>
    $(document).ready(function() {
        $('#example').DataTable();
    });
</script>
<script src="<?php echo base_url('asset\js\script.js') ?>"></script>
</html>