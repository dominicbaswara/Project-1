<body>

    <body>
        <div class="home" id="formDashboard">
            <div class="home-content">
                <div class="admin-button">
                    <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                        data-bs-target="#tambahAdminModal" style="margin-left: 5rem;">Input Data Admin</button>
                </div>
                <div class="card tabel">
                    <div align="left" style="margin: 1rem calc(100rem/30);">
                        <h2 style="margin-top: 1rem; margin-bottom:1rem; margin-left:1rem;">Data Admin</h2>
                        <table id="example" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Kode Admin</th>
                                    <th>USERNAME</th>
                                    <th>NAMA</th>
                                    <th>ALAMAT</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
    								foreach ($Admin as $row) {
    									echo "
    										<tr>
    											<td>" . $row['Kd_Admin'] . "</td>
    											<td>" . $row['Username'] . "</td>
    											<td>" . $row['Nama'] . "</td>
    											<td>" . $row['Alamat'] . "</td>
    											<td>
    												<div class='btn-group' role='group' aria-label='Basic outlined example'>
    													<button type='button' class='btn btn-outline-primary' data-bs-toggle='modal' data-bs-target='#editAdminModal" . $row['Kd_Admin'] . "'>Edit</button>
    													<a class='btn btn-outline-primary' href='" . base_url('dashboard/delete?Kd_Admin=' . $row['Kd_Admin']) . "'>Delete</a> 

    													<div class='modal fade' id='editAdminModal" . $row['Kd_Admin'] . "' tabindex='-1' aria-labelledby='exampleModalLabel' aria-hidden='true'>
    														<div class='modal-dialog'>
    															<div class='modal-content'>
    																<div class='modal-header'>
    																	<h1 class='modal-title fs-5' id='exampleModalLabel'>Edit Data Admin</h1>
    																	<button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
    																</div>
                                    								<div class='modal-body'>" ?>
                                                                        <form action='<?= base_url('dashboard/editAdmin')  ?>' method='POST' enctype='multipart/form-data'>
                                                                        <?= "
                                                                        <div class='mb-3'>
                                                                            <label for='recipient-name' class='col-form-label'>Kode Admin :</label>
                                                                            <input type='text' class='form-control' name='kdAdmin' readonly value='" . $row['Kd_Admin'] . "'>
                                                                        </div>
                                                                        <div class='mb-3'>
                                                                            <label for='message-text' class='col-form-label'>Username :</label>
                                                                            <input type='text' class='form-control' name='username'  value='" . $row['Username'] . "'>
                                                                        </div>
                                                                        <div class='mb-3'>
                                                                            <label for='message-text' class='col-form-label'>Password :</label>
                                                                            <input type='password' class='form-control' name='password'>
                                                                        </div>
                                                                        <div class='mb-3'>
                                                                            <label for='message-text' class='col-form-label'>Nama :</label>
                                                                            <input type='text' class='form-control' name='nama'  value='" . $row['Nama'] . "'>
                                                                        </div>
                                                                        <div class='mb-3'>
                                                                            <label for='message-text' class='col-form-label'>Alamat :</label>
                                                                            <input type='text' class='form-control' name='alamat'  value='" . $row['Alamat'] . "'>
                                                                        </div>
                                                                    </div>
                                                                    <div class='modal-footer'>
                                                                        <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Close</button>
                                                                        <button type='submit' class='btn btn-primary'>Edit Data</button>
                                                                    </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        ";
    								}
								?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="tambahAdminModal" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Data Admin</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo base_url('dashboard/tambahAdmin')  ?>" method="POST"
                            enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="recipient-name" class="col-form-label">Kode Admin :</label>
                                <input type="text" class="form-control" name="kdAdmin">
                            </div>
                            <div class="mb-3">
                                <label for="message-text" class="col-form-label">Username :</label>
                                <input type="text" class="form-control" name="username">
                            </div>
                            <div class="mb-3">
                                <label for="message-text" class="col-form-label">Password :</label>
                                <input type="password" class="form-control" name="password">
                            </div>
                            <div class="mb-3">
                                <label for="message-text" class="col-form-label">Nama :</label>
                                <input type="text" class="form-control" name="nama">
                            </div>
                            <div class="mb-3">
                                <label for="message-text" class="col-form-label">Alamat :</label>
                                <input type="text" class="form-control" name="alamat">
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Tambah Data</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>

    </body>
    <script>
    $(document).ready(function() {
        $('#example').DataTable();
    });
    </script>
    <script src="<?php echo base_url('asset\js\script.js') ?>"></script>

    </html>
</body>