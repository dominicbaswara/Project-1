<body>
	<div class="home" id="formDashboard">
		<div class="home-content">
		<div class="mobil-button">
			<button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#tambahMobilModal" style="margin-left: 5rem;">Input Data Mobil</button>
		</div>
			<div class="card tabel">
				<div align="left" style="margin: 1rem calc(100rem/30);">
					<h2 style="margin-top: 1rem; margin-bottom:1rem; margin-left:1rem;">Data Mobil</h2>
					<table id="example" class="table table-striped table-bordered" style="width:100%">
							<thead>
								<tr>
									<th>Kode Kendaraan</th>
									<th>Nomor Polisi</th>
									<th>Merk</th>
									<th>Nama</th>
									<th>Harga Sewa</th>
									<th>Aksi</th>

								</tr>
							</thead>
							<tbody>
								<?php
								foreach ($mobil as $row)
									echo "
										<tr>
											<td>" . $row['Kd_Mobil'] . "</td>
											<td>" . $row['Nomor_Polisi'] . "</td>
											<td>" . $row['Merk'] . "</td>
											<td>" . $row['Nama'] . "</td>
											<td>" . $row['Harga_Sewa'] . "</td>
											<td>
    												<div class='btn-group' role='group' aria-label='Basic outlined example'>
    													<a class='btn btn-outline-primary' href='" . base_url('dashboard/deleteMobil?Kd_Mobil=' . $row['Kd_Mobil']) . "'>Delete</a> 
    												</div>
    										</td>
										</tr>
									";
								?>
							</tbody>
						</table>
				</div>
			</div>
		</div>
	</div>
	<!-- Modal -->
	<div class="modal fade" id="tambahMobilModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Data Mobil</h1>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
						</div>
					<div class="modal-body">
						<form action="<?= base_url('dashboard/tambahMobil')  ?>" method="POST"
						enctype="multipart/form-data">
							<div class="mb-3">
								<label for="recipient-name" class="col-form-label">Kode Kendaraan :</label>
								<input type="text" class="form-control" name="kdMobil">
							</div>
							<div class="mb-3">
								<label for="message-text" class="col-form-label">Nomor Polisi :</label>
								<input type="text" class="form-control" name="nopol">
							</div>
							<div class="mb-3">
								<label for="message-text" class="col-form-label">Merk :</label>
								<input type="text" class="form-control" name="merk">
							</div>
							<div class="mb-3">
								<label for="message-text" class="col-form-label">Nama :</label>
								<input type="text" class="form-control" name="nama">
							</div>
							<div class="mb-3">
								<label for="message-text" class="col-form-label">Harga Sewa :</label>
								<input type="text" class="form-control" name="hargaSewa">
							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
								<button type="submit" class="btn btn-primary">Tambah Data</button>
							</div>
						</form>
					</div>
				</div>
		</div>
	</div>

</body>
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    });
</script>
<script src="<?php echo base_url('asset\js\script.js') ?>"></script>
</html>