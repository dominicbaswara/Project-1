<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Regist extends CI_Controller
{

    public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->model('M_Register');
	}

    public function index()
	{
		$this->load->view('loginPage');
	}

	public function register(){
		$this->form_validation->set_rules('username', 'Username', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');
		$this->form_validation->set_rules('name', 'Nama', 'required');
		$this->form_validation->set_rules('alamat', 'Alamat', 'required');

		if ($this->form_validation->run() == false) {
			$this->index();
		} else {
			$this->_register();
		}
	}

public function registadmin(){
		$this->form_validation->set_rules('username', 'Username', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');
		$this->form_validation->set_rules('nama', 'Nama', 'required');
		$this->form_validation->set_rules('alamat', 'Alamat', 'required');
		// $this->form_validation->set_rules('RadioOptions', 'Choice', 'required');
		// $this->form_validation->set_rules('alamat', 'Alamat', 'required');
		if ($this->form_validation->run() == false) {
			$this->index();
		} else {
			$this->_register();
		}
	}


	private function _register() {
		$User = $this->input->post('username');
		$Pass = $this->input->post('password');
		$Nama = $this->input->post('nama');
		// $Email = $this->input->post('email');
		// $NoTlp = $this->input->post('NoTelp');
		// $Kategori = $this->input->post('RadioOptions');
		$Alamat = $this->input->post('alamat');
		$options = [
        	'cost' => 10,
    	];
		$Password = password_hash($Pass,PASSWORD_DEFAULT,$options);
		// $token=bin2hex(random_bytes(8));
		// $otoritas = 'Admin';
		
		$this->M_Register->Register($User,$Password,$Nama,$Alamat);
		// $this->sendEmail($Email,$token);
		redirect(site_url('loginPage'));
	}
}