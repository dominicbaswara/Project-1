<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Admin_model');
        $this->load->library('session');
    }

    public function index()
    {
        $this->load->view('loginpage');
    }

    public function logadmin()
    {
        $this->form_validation->set_rules('username', 'Username', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');
        
        if ($this->form_validation->run() == false) {
            $this->load->view('loginpage');
        } else {
            $this->_login_admin();
        }
    }

    private function _login_admin()
    {
        $User = $this->input->post('username');
        $Pass = $this->input->post('password');

        $admin = $this->Admin_model->get_admin($User);

        if ($admin != null) {
            if (password_verify($Pass, $admin['Password'])) {
                $session_data = [
                    'username' => $admin['Username'],
                    'logged_in' => true
                ];
                $this->session->set_userdata($session_data);
                redirect('dashboard');
            } else {
                $this->session->set_flashdata('error', 'Password salah. Silahkan coba lagi!');
                redirect('login');
            }
        } else {
            $this->session->set_flashdata('error', 'Username tidak terdaftar. Silahkan coba lagi!');
            redirect('login');
        }
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect('login');
    }
}
