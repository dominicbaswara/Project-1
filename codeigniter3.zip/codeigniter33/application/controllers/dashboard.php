<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            redirect('login');
            $this->load->library('form_validation');
        }
    }

    public function index()
    {
        $data['title'] = 'Dashboard';
        $data['Admin'] = $this->db->get('admin')->result_array();
        $this->load->view('dashboard', $data);
        $this->load->view('template/sidebar');
    }

    public function dtAdmin()
    {
        $data['title'] = 'Data Admin';
        $data['Admin'] = $this->db->get('admin')->result_array();
        $this->load->view('template/sidebar', $data);
        $this->load->view('dataAdmin', $data);
    }

    public function tambahAdmin()
    {
        $this->form_validation->set_rules('kdAdmin', 'Kode Admin', 'required');
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', 'Data Admin gagal ditambahkan');
            $this->load->view('dataAdmin');
        } else {
            $data = [
                'Kd_Admin' => $this->input->post('kdAdmin'),
                'Username' => $this->input->post('username'),
                'Password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
                'Nama' => $this->input->post('nama'),
                'Alamat' => $this->input->post('alamat')
            ];

            $this->Admin_model->insert_data($data);
            $this->session->set_flashdata('notifikasi', 'Data Admin berhasil ditambahkan');
            return redirect('dashboard/dtAdmin');
        }
    }

    public function editAdmin()
    {
        $this->form_validation->set_rules('kdAdmin', 'Kode Admin', 'required');
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        if ($this->form_validation->run() == false) {
            return redirect('dashboard/dtAdmin');
        } else {
            $kdAdmin = $this->input->post('kdAdmin');
            $username = $this->input->post('username');
            $password = password_hash($this->input->post('password'), PASSWORD_DEFAULT);
            $nama = $this->input->post('nama');
            $alamat = $this->input->post('alamat');

            $data = array(
                'Kd_Admin' => $kdAdmin,
                'Username' => $username,
                'Password' => $password,
                'Nama' => $nama,
                'Alamat' => $alamat,
            );
            $where = array(
                'Kd_Admin' => $kdAdmin
            );
            $this->Admin_model->update($where, $data);
            return redirect('dashboard/dtAdmin');
        }
    }

    public function delete()
    {
        $id = $_GET['Kd_Admin'];
        $this->Admin_model->delete($id);
        $this->session->set_flashdata('message', 'Data admin berhasil dihapus');
        return redirect('dashboard/dtAdmin');
    }


    public function dtMobil()
    {
        $data['title'] = 'Data Mobil';
        $data['mobil'] = $this->db->get('mobil')->result_array();
        $data['flashdata'] = $this->session->flashdata('notifikasi');
        $data['flashdata_error'] = $this->session->flashdata('error');

        $this->load->view('template/sidebar', $data);
        $this->load->view('dataMobil', $data);
    }

    public function tambahMobil(){
        $this->form_validation->set_rules('kdMobil', 'Kode Mobil', 'required');
        $this->form_validation->set_rules('nopol', 'Nomor Polisi', 'required');
        $this->form_validation->set_rules('merk', 'Merk', 'required');
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('hargaSewa', 'Harga', 'required');
        if ($this->form_validation->run() == false) {
            $this->session->set_flashdata('error', 'Data mobil gagal ditambahkan');
            return redirect ('dashboard/dtMobil');
        } else {
            $data = [
             'Kd_Mobil' => $this->input->post('kdMobil'),
             'Nomor_Polisi' => $this->input->post('nopol'),
             'Merk' => $this->input->post('merk'),
             'Nama' => $this->input->post('nama'),
             'Harga_Sewa' => $this->input->post('hargaSewa')
            ];

            $this->Admin_model->insert_mobil($data);
            $this->session->set_flashdata('notifikasi', 'Data mobil berhasil ditambahkan');
            return redirect('dashboard/dtMobil');
        }
    }

    public function deleteMobil()
    {
    $id = $_GET['Kd_Mobil'];
    $this->Admin_model->deleteMobil($id);
    $this->session->set_flashdata('message', 'Data Mobil berhasil dihapus');
    return redirect('dashboard/dtMobil');
    }


    public function dtSupir()
    {
        $data['title'] = 'Data Supir';
        $data['Supir'] = $this->db->get('Supir')->result_array();
        $this->load->view('template/sidebar', $data);
        $this->load->view('dataSupir', $data);
    }

    public function tambahSupir(){
        $this->form_validation->set_rules('kdSupir', 'Kode Supir', 'required');
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        $this->form_validation->set_rules('nomor', 'Nomor Telephone', 'required');
        $this->form_validation->set_rules('biaya', 'Biaya', 'required');
        if ($this->form_validation->run() == false){
            $this->session->set_flashdata('error', 'Data Supir gagal ditambahkan');
            return redirect('dashboard/dtSupir');
        } else {
            $data = [
            'Kd_Supir' => $this->input->post('kdSupir'),
            'Nama' => $this->input->post('nama'),
            'Alamat' => $this->input->post('alamat'),
            'Nomor' => $this->input->post('nomor'),
            'Biaya' => $this->input->post('biaya')
            ];
            $this->Admin_model->insert_supir($data);
            $this->session->set_flashdata('notifikasi', 'Data supir berhasil ditambahkan');
            return redirect('dashboard/dtSupir');
        }
    }

    public function editSupir(){

            $this->form_validation->set_rules('kdSupir', 'Kode Supir', 'required');
            $this->form_validation->set_rules('nama', 'Nama', 'required');
            $this->form_validation->set_rules('alamat', 'Alamat', 'required');
            $this->form_validation->set_rules('nomor', 'Nomor Telephone', 'required');
            $this->form_validation->set_rules('biaya', 'Biaya', 'required');
            if ($this->form_validation->run()==false){
                return redirect('dashboard/dtSupir');
            } else {
                $kdSupir = $this->input->post('kdSupir');
                $nama = $this->input->post('nama');
                $alamat = $this->input->post('alamat');
                $nomor = $this->input->post('nomor');
                $biaya = $this->input->post('biaya');

                $data = array(
                'Kd_Supir' => $kdSupir,
                'Nama' => $nama,
                'Alamat' => $alamat,
                'Nomor' => $nomor,
                'Biaya' => $biaya
                );
                $where = array(
                    'Kd_Supir' => $kdSupir
                );
                $this->Admin_model->updateSupir($where, $data);
                return redirect('dashboard/dtSupir');
            }
    }

    public function deleteSupir(){
        $id = $_GET['Kd_Supir'];
        $this->Admin_model->deleteSupir($id);
        $this->session->set_flashdata('message', 'Data Supir berhasil dihapus');
        return redirect('dashboard/dtSupir');
    }

    public function dtPenyewa(){
        $data['title'] = 'Data Penyewa';
        $data['Penyewa'] = $this->db->get('Penyewa')->result_array();
        $this->load->view('template/sidebar');
        $this->load->view('dataPenyewa', $data);
    }

    public function tambahPenyewa()
{
    $this->form_validation->set_rules('kdPenyewa', 'Kode Penyewa', 'required');
    $this->form_validation->set_rules('nama', 'Nama', 'required');
    $this->form_validation->set_rules('alamat', 'Alamat', 'required');
    $this->form_validation->set_rules('nomor', 'Nomor Telephone', 'required');

    if ($this->form_validation->run() == FALSE) {
        $this->session->set_flashdata('error', 'Data Penyewa gagal ditambahkan');
        return redirect('dashboard/dtPenyewa');
    } else {
        $config['upload_path'] = './asset/image-upload';
        $config['allowed_types'] = 'jpeg|jpg|png';
        $config['max_size'] = 2048;

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('foto')) {
            $this->session->set_flashdata('error', $this->upload->display_errors());
            return redirect('dashboard/dtPenyewa');
        } else {
            $upload_data = $this->upload->data();
            // Data yang akan disimpan ke dalam database
            $data = [
                'Kd_Penyewa' => $this->input->post('kdPenyewa'),
                'Foto_Penyewa' => $upload_data['file_name'], // Mengambil nama file yang diupload
                'Nama' => $this->input->post('nama'),
                'Alamat' => $this->input->post('alamat'),
                'Nomor_Telepon' => $this->input->post('nomor')
            ];

            $this->Admin_model->insert_penyewa($data);
            $this->session->set_flashdata('notifikasi', 'Data Penyewa berhasil ditambahkan');
            return redirect('dashboard/dtPenyewa');
        }
    }
}

public function deletePenyewa() {
    $id = $this->input->get('Kd_Penyewa'); // Menggunakan input->get untuk mengambil parameter dari URL
    $this->Admin_model->deletePenyewa($id);
    $this->session->set_flashdata('message', 'Data Penyewa berhasil dihapus');
    return redirect('dashboard/dtPenyewa');
}

    public function dtSewa()
    {
        $data['title'] = 'Data Sewa';
        $data['Sewa'] = $this->db->get('Sewa')->result_array();
        $data['Mobil'] = $this->db->get('Mobil')->result_array();
        $data['Supir'] = $this->db->get('Supir')->result_array();
        $data['Penyewa'] = $this->db->get('Penyewa')->result_array();
        $this->load->view('template/sidebar', $data);
        $this->load->view('dataSewa', $data);
    }

    public function tambahSewa(){
        $this->form_validation->set_rules('kdSewa', 'Kode Sewa', 'Required');
        $this->form_validation->set_rules('kdMobil', 'Kode Mobil', 'Required');
        $this->form_validation->set_rules('kdSupir', 'Kode Supir', 'Required');
        $this->form_validation->set_rules('kdPenyewa', 'Kode Penyewa', 'Required');
        $this->form_validation->set_rules('tanggalSewa', 'Tanggal Sewa', 'Required');
        $this->form_validation->set_rules('tanggalPengembalian', 'Pengembalian Sewa', 'Required');
        if ($this->form_validation->run() == false){
            $this->session->set_flashdata('error', 'Data sewa gagal ditambahkan');
            return redirect ('dashboard/dtSewa');
        } else {
            $data = [
                'Kd_Sewa' => $this->input->post('kdSewa'),
                'Kd_Mobil' => $this->input->post('kdMobil'),
                'Kd_Supir' => $this->input->post('kdSupir'),
                'Kd_Penyewa' => $this->input->post('kdPenywa'),
                'Tgl_Sewa' => $this->input->post('tanggalSewa'),
                'Tgl_Pengembalian' => $this->input->post('tanggalPengembalian'),
                'Total_Biaya' => $this->input->post('biaya')
            ];
            $this->Admin_model->insert_sewa($data);
            $this->session->set_flashdata('notifikasi', 'Data sewa berhasil ditambahkan');
            return redirect('dashboard/dtSewa');
        }
        
    }

    public function editSewa(){
        $this->form_validation->set_rules('kdSewa', 'Kode Sewa', 'Required');
        $this->form_validation->set_rules('kdMobil', 'Kode Mobil', 'Required');
        $this->form_validation->set_rules('kdSupir', 'Kode Supir', 'Required');
        $this->form_validation->set_rules('kdPenyewa', 'Kode Penyewa', 'Required');
        $this->form_validation->set_rules('tanggalSewa', 'Tanggal Sewa', 'Required');
        $this->form_validation->set_rules('tanggalPengembalian', 'Pengembalian Sewa', 'Required');
        $this->form_validation->set_rules('biaya', 'Total biaya', 'required');
        if ($this->form_validation->run() == false ){
            $this->session->set_flashdata('error', 'Data sewa gagal diubah');
            return redirect('dashboard/dtSewa');
        } else {
            $kdSewa = $this->input->post('kdSewa');
            $kdMobil = $this->input->post('kdMobil');
            $kdSupir = $this->input->post('kdSupir');
            $kdPenyewa = $this->input->post('kdPenyewa');
            $tanggalSewa = $this->input->post('tanggalSewa');
            $tanggalPengembalian = $this->input->post('tanggalPengembalian');
            $biayaSewa = $this->input->post('biaya');

            $data = array(
                'Kd_Sewa' => $kdSewa,
                'Kd_Mobil' => $kdMobil,
                'Kd_Supir' => $kdSupir,
                'Tgl_Sewa' => $tanggalSewa,
                'Tgl_Pengembalian' => $tanggalPengembalian,
                'Total_Biaya' => $biayaSewa,
                );
                $where = array(
                    'Kd_Sewa' => $kdSewa
                );
                $this->Admin_model->updateSewa($where, $data);
                return redirect('dashboard/dtSewa');
        }

    }

    public function dtTransaksi()
    {
        $data['title'] = 'Data Transaksi';
        $data['Transaksi'] = $this->db->get('Transaksi')->result_array();
        $data['Admin'] = $this->db->get('Admin')->result_array();
        $this->load->view('template/sidebar', $data);
        $this->load->view('dataTransaksi', $data);
    }

    public function tambahTransaksi()
    {
        $this->form_validation->set_rules('kdTransaksi', 'Kode Transaksi', 'Required');
        $this->form_validation->set_rules('kdTransaksi', 'Kode Transaksi', 'Required');
        $this->form_validation->set_rules('kdTransaksi', 'Kode Transaksi', 'Required');
        $this->form_validation->set_rules('kdTransaksi', 'Kode Transaksi', 'Required');
        if ($this->form_validation->run()== false){
            $this->session->set_flashdata('error', 'Data Transaksi gagal ditambahkan');
            return redirect('dashboard/dtTransaksi');
        } else {
            $data = [
                'Kd_Transaksi' => $this->input->post('kdTransaksi'),
                'Kd_Admin' => $this->input->post('kdAdmin'),
                'Kd_DTransaksi' => $this->input->post('DTransaksi'),
                'Metode_Pembayaran' => $this->input->post('pembayaran'),
            ];
            $this->Admin_model->insert_transaksi($data);
            $this->session->set_flashdata('notifikasi', 'Data Transaksi berhasil ditambahkan');
            return redirect('dashboard/dtTransaksi');
        }
    }
}